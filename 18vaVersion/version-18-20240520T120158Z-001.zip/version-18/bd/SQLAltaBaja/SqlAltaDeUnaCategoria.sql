INSERT INTO categorias (idCategorias, CategoriaDescripcion, RangoidPlantas) VALUES (4, 'Arbustos', '3000 a 3999');
SELECT * FROM RinconBotanico.categorias;

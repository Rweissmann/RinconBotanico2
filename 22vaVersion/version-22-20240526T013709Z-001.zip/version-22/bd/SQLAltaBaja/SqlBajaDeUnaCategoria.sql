DELETE FROM categorias Where idCategorias=4;
SELECT * FROM rinconbotanico.categorias;
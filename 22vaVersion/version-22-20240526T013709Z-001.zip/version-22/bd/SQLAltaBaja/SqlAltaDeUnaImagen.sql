INSERT INTO imagenes (idPlantas, ImagenesLinkFoto) VALUES (2010, './img/002010.jpg' );
SELECT * FROM rinconbotanico.imagenes;
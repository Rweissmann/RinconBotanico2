DELETE FROM dataplantas Where idPlantas=2010;
SELECT * FROM rinconbotanico.dataplantas;
INSERT INTO plantas (idPlantas, PlantasNombre, idCategoria, CategoriaDescripcion) VALUES (2010, 'Frambuesa Negra', 4, 'Arbusto' );
SELECT * FROM rinconbotanico.plantas;